<h1>Авторизация</h1>
<form method="post" action="<?php echo e(route('auth')); ?>">
	<?php echo csrf_field(); ?>
	<input type="email" placeholder="email" name="email" id="email">
	<input type="password" placeholder="Пароль" name="password" id="password">
	<input type="checkbox" id="remember" name="remember">
	<button type="submite">Войти</button>
</form>
<?php /**PATH E:\OSPanel\OpenServer\domains\Laravel\TFSO\resources\views\auth.blade.php ENDPATH**/ ?>