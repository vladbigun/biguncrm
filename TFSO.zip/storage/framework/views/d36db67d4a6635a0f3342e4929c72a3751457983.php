<div class="side-menu">
	<div class="logo"><img src="/img/favicon.png"></div>
	<ul class="nav">
		<li><a href="<?php echo e(route('home')); ?>"><img class="icon" src="/img/glav.svg"></a></li>
		<li><a href="<?php echo e(route('orders')); ?>"><img class="icon" src="/img/orders.svg"></a></li>
		<li><a href="<?php echo e(route('product')); ?>"><img class="icon" src="/img/product.svg"></a></li>
		<li><a href="<?php echo e(route('payments')); ?>"><img class="icon" src="/img/money.svg"></a></li>
		<li><a href="<?php echo e(route('setings')); ?>"><img class="icon" src="/img/setings.svg"></a></li>
	</ul>
</div><?php /**PATH E:\OSPanel\OpenServer\domains\Laravel\TFSO\resources\views/inc/header.blade.php ENDPATH**/ ?>