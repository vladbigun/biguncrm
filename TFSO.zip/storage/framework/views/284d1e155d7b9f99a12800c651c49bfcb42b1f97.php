

<?php $__env->startSection('title', 'Заказ'); ?>

<?php $__env->startSection('content'); ?>
<h1><?php echo $__env->yieldContent('title'); ?> №<?php echo e($data->id); ?></h1>
<a href="/orders">Назад</a>

<div class="alert">
	<h1>Имя: <?php echo e($data->name); ?></h1>
	<h2>Номер телефона: <?php echo e($data->phone_number); ?></h2>
	<h2>Комментарий: <?php echo e($data->message); ?></h2>
	<p>Сумма: <?php echo e($data->sum); ?> Статус: <?php echo e($data->status); ?> ТТН: <?php echo e($data->ttn); ?></p>
	<a href="<?php echo e(route('order-delete', $data->id)); ?>">Удалить</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\OpenServer\domains\Laravel\TFSO\resources\views\ordersOne.blade.php ENDPATH**/ ?>