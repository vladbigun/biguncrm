

<?php $__env->startSection('title', 'Новый заказ'); ?>

<?php $__env->startSection('content'); ?>
<h1><?php echo $__env->yieldContent('title'); ?></h1>

<form action="<?php echo e(route('orderCreate')); ?>" method="post">
	<?php echo csrf_field(); ?>
	<label>ФИО</label>
    <input type="text" name="surname" placeholder="Фамилия">
	<input type="text" name="name" placeholder="Имя">
	<input type="text" name="middle_name" placeholder="Отчество">
	<br><label>Остальное</label>
	<input type="text" name="phone_number" placeholder="Номер телефона">
	<input type="text" name="sum" placeholder="Сумма">
	<input type="text" name="ttn" placeholder="ТТН">
	<input type="text" name="message" placeholder="Комментарий">
	<br><br>
	<input type="submit">
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\OpenServer\domains\Laravel\TFSO\resources\views/orderNew.blade.php ENDPATH**/ ?>