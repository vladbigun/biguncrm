

<?php $__env->startSection('title', 'Заказы'); ?>

<?php $__env->startSection('content'); ?>
<h1><?php echo $__env->yieldContent('title'); ?></h1>
<div id="app "></div>
<form method="get" action="<?php echo e(route('search')); ?>">
	
		<input type="text" name="s" placeholder="Введите имя">
		<button type="submite">Поиск</button>
	</form>

<table class="tableOrder">
	<tr style="background-color: #0c0c0c; color: white">
	<th>№</th>
	<th>ФИО</th>
	<th>СУММА</th>
	<td>ОПЛАТА</th>
	<th>СТАТУС</th>
	<th>ТТН</th>
</tr>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr onclick="document.location='<?php echo e(route('order-data-one', $el->id)); ?>'">
	<td><?php echo e($el->id); ?></td>
	<td><?php echo e($el->surname); ?> <?php echo e($el->name); ?> <?php echo e($el->middle_name); ?></td>
	<td><?php echo e($el->sum); ?></td>
	<td><?php echo e($el->payment); ?></td>
	<td><?php echo e($el->status); ?></td>
	<td><?php echo e($el->ttn); ?></td>
	
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<a href="<?php echo e(route('orderNew')); ?>">Новый заказ</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\OSPanel\OpenServer\domains\Laravel\TFSO\resources\views\orders.blade.php ENDPATH**/ ?>