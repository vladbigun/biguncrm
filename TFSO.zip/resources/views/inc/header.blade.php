<div class="side-menu">
	<div class="logo"><img src="/img/favicon.png"></div>
	<ul class="nav">
		<li><a href="{{route('home')}}"><img class="icon" src="/img/glav.svg"></a></li>
		<li><a href="{{route('orders')}}"><img class="icon" src="/img/orders.svg"></a></li>
		<li><a href="{{route('product')}}"><img class="icon" src="/img/product.svg"></a></li>
		<li><a href="{{route('payments')}}"><img class="icon" src="/img/money.svg"></a></li>
		<li><a href="{{route('setings')}}"><img class="icon" src="/img/setings.svg"></a></li>
	</ul>
</div>