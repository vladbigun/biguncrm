@extends('layouts.app')

@section('title', 'Главная')

@section('content')
<h1>Главная</h1>


@endsection