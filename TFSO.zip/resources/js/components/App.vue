<template>
<div>

<navbar />
<div class="container-fluid">

    <div class="content">
    	<router-view></router-view>
    </div>
    <div class="footer"><h2>BigunCRM v0.0.1</h2></div>
    
</div>
</div>
</template>